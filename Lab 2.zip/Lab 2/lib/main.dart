import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class ClothingItem {
  String name;
  String color; // Added property
  String size; // Added property

  ClothingItem({required this.name, required this.color, required this.size});
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData.dark(), // Set the overall dark theme
      home: ClothingList(),
    );
  }
}

class ClothingList extends StatefulWidget {
  @override
  _ClothingListState createState() => _ClothingListState();
}

class _ClothingListState extends State<ClothingList> {
  List<ClothingItem> _clothingItems = [];
  TextEditingController _nameController = TextEditingController();
  TextEditingController _colorController = TextEditingController(); // Added controller
  TextEditingController _sizeController = TextEditingController(); // Added controller
  bool _isEditing = false;
  int _editingIndex = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Clothing List'),

        // Set the background color of the app bar for dark mode
        backgroundColor: Colors.green,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text(
              'Select Clothing',
              style: TextStyle(color: Colors.green),
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: _clothingItems.length,
              itemBuilder: (context, index) {
                return Card(
                  color: Colors.green, // Set the background color of the item
                  child: ListTile(
                    title: Text(
                      _clothingItems[index].name,
                      style: TextStyle(color: Colors.blue[800]), // Set text color to blue
                    ),
                    subtitle: Text(
                      'Color: ${_clothingItems[index].color}, Size: ${_clothingItems[index].size}',
                      style: TextStyle(color: Colors.blue[700]), // Set text color to blue
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit, color: Colors.red),
                          onPressed: () {
                            _startEditing(index);
                          },
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () {
                            _deleteItem(index);
                          },
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          FloatingActionButton(
            backgroundColor: Colors.green,
            foregroundColor: Colors.red,
            onPressed: () {
              _showAddDialog();
            },
            child: Icon(Icons.add),
          ),
          SizedBox(height: 16),
        ],
      ),
    );
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('Add Clothing Item:'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: _nameController,
                decoration: InputDecoration(hintText: 'Enter clothing name'),
              ),
              TextField(
                controller: _colorController,
                decoration: InputDecoration(hintText: 'Enter color'),
              ),
              TextField(
                controller: _sizeController,
                decoration: InputDecoration(hintText: 'Enter size'),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context);
                _addItem();
              },
              style: ElevatedButton.styleFrom(
                primary: Colors.green,
                onPrimary: Colors.red,
              ),
              child: Text('Add'),
            ),
          ],
        );
      },
    );
  }

  void _addItem() {
    setState(() {
      final itemName = _nameController.text;
      final itemColor = _colorController.text;
      final itemSize = _sizeController.text;

      if (itemName.isNotEmpty && itemColor.isNotEmpty && itemSize.isNotEmpty) {
        if (_isEditing) {
          _clothingItems[_editingIndex].name = itemName;
          _clothingItems[_editingIndex].color = itemColor; // Update color property
          _clothingItems[_editingIndex].size = itemSize; // Update size property
          _isEditing = false;
        } else {
          _clothingItems
              .add(ClothingItem(name: itemName, color: itemColor, size: itemSize));
        }

        _nameController.clear();
        _colorController.clear();
        _sizeController.clear();
      }
    });
  }

  void _startEditing(int index) {
    setState(() {
      _nameController.text = _clothingItems[index].name;
      _colorController.text = _clothingItems[index].color;
      _sizeController.text = _clothingItems[index].size;
      _isEditing = true;
      _editingIndex = index;
      _showAddDialog();
    });
  }

  void _deleteItem(int index) {
    setState(() {
      _clothingItems.removeAt(index);
    });
  }
}
