import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: 'AIzaSyCaCLfatg2AHs9MOrJ72XRMxWWFdoVGBeI',
      authDomain: 'colloquiums-7830b.firebaseapp.com',
      projectId: 'colloquiums-7830b',
      storageBucket: 'colloquiums-7830b.appspot.com',
      messagingSenderId: '611129670110',
      appId: '1:611129670110:android:315f769a929ed4b82cc54f',
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AuthProvider(),
      child: MaterialApp(
        title: 'Colloquium App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: AuthWrapper(),
      ),
    );
  }
}

class AuthProvider with ChangeNotifier {
  FirebaseAuth _auth = FirebaseAuth.instance;

  User? get user => _auth.currentUser;

  Future<void> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      notifyListeners();
    } catch (e) {
      // Handle errors
      print(e);
    }
  }

  Future<void> signUp(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      notifyListeners();
    } catch (e) {
      // Handle errors
      print(e);
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    notifyListeners();
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    if (authProvider.user == null) {
      return LoginPage();
    } else {
      return ColloquiumPage();
    }
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                final email = emailController.text.trim();
                final password = passwordController.text.trim();
                Provider.of<AuthProvider>(context, listen: false).signIn(email, password);
              },
              child: Text('Sign In'),
            ),
            SizedBox(height: 8),
            TextButton(
              onPressed: () {
                final email = emailController.text.trim();
                final password = passwordController.text.trim();
                Provider.of<AuthProvider>(context, listen: false).signUp(email, password);
              },
              child: Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}

class ColloquiumPage extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController timeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Colloquiums'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).signOut();
            },
          ),
        ],
      ),
      body: ColloquiumList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AddColloquiumDialog(),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class AddColloquiumDialog extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController timeController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add Colloquium'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: nameController,
            decoration: InputDecoration(labelText: 'Name'),
          ),
          TextField(
            controller: dateController,
            decoration: InputDecoration(labelText: 'Date'),
          ),
          TextField(
            controller: timeController,
            decoration: InputDecoration(labelText: 'Time'),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () {
            final name = nameController.text.trim();
            final date = dateController.text.trim();
            final time = timeController.text.trim();

            if (name.isNotEmpty && date.isNotEmpty && time.isNotEmpty) {
              addColloquium(context, name, date, time);
              Navigator.of(context).pop();
            } else {
              // Show error message or handle empty fields
            }
          },
          child: Text('Add'),
        ),
      ],
    );
  }

  void addColloquium(BuildContext context, String name, String date, String time) {
    final userId = Provider.of<AuthProvider>(context, listen: false).user?.uid;

    if (userId != null) {
      FirebaseFirestore.instance.collection('colloquiums').doc(userId).collection('user_colloquiums').add({
        'name': name,
        'date': date,
        'time': time,
      });
    }
  }
}

class ColloquiumList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final userId = Provider.of<AuthProvider>(context).user?.uid;

    if (userId != null) {
      return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('colloquiums').doc(userId).collection('user_colloquiums').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return CircularProgressIndicator();
          }

          final colloquiums = snapshot.data?.docs ?? [];

          return GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: colloquiums.length,
            itemBuilder: (context, index) {
              final colloquium = colloquiums[index];
              final name = colloquium['name'];
              final date = colloquium['date'];
              final time = colloquium['time'];

              return Card(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      name,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('$date\n$time', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                  ],
                ),
              );
            },
          );
        },
      );
    } else {
      return Center(
        child: Text('User not authenticated'),
      );
    }
  }
}
