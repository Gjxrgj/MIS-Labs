import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:table_calendar/table_calendar.dart';
import 'package:location/location.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

void openGoogleMaps(LatLng destination) async {
  final url = 'https://www.google.com/maps/dir/?api=1&destination=${destination.latitude},${destination.longitude}';
  if (await canLaunch(url)) {
    await launch(url);
  } else {
    print('Could not launch Google Maps.');
  }
}

class MapsScreen extends StatelessWidget {
  final LatLng eventLocation;

  MapsScreen({required this.eventLocation});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Event Location'),
      ),
      body: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: eventLocation,
          zoom: 14.0,
        ),
        markers: {
          Marker(
            markerId: MarkerId('event_marker'),
            position: eventLocation,
            infoWindow: InfoWindow(title: 'Event Location'),
          ),
        },
      ),
    );
  }
}

class LocationService {
  final Location _location = Location();

  Future<LocationData?> getCurrentLocation() async {
    try {
      return await _location.getLocation();
    } catch (e) {
      print("Error getting location: $e");
      return null;
    }
  }
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: FirebaseOptions(
      apiKey: 'AIzaSyCaCLfatg2AHs9MOrJ72XRMxWWFdoVGBeI',
      authDomain: 'colloquiums-7830b.firebaseapp.com',
      projectId: 'colloquiums-7830b',
      storageBucket: 'colloquiums-7830b.appspot.com',
      messagingSenderId: '611129670110',
      appId: '1:611129670110:android:315f769a929ed4b82cc54f',
    ),
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => AuthProvider(),
      child: MaterialApp(
        title: 'Colloquium App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
        ),
        home: AuthWrapper(),
      ),
    );
  }
}

class AuthProvider with ChangeNotifier {
  FirebaseAuth _auth = FirebaseAuth.instance;

  User? get user => _auth.currentUser;

  Future<void> signIn(String email, String password) async {
    try {
      await _auth.signInWithEmailAndPassword(email: email, password: password);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }

  Future<void> signUp(String email, String password) async {
    try {
      await _auth.createUserWithEmailAndPassword(email: email, password: password);
      notifyListeners();
    } catch (e) {
      print(e);
    }
  }

  Future<void> signOut() async {
    await _auth.signOut();
    notifyListeners();
  }
}

class AuthWrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authProvider = Provider.of<AuthProvider>(context);

    if (authProvider.user == null) {
      return LoginPage();
    } else {
      return ColloquiumPage();
    }
  }
}

class LoginPage extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(
              controller: emailController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: passwordController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 16),
            ElevatedButton(
              onPressed: () {
                final email = emailController.text.trim();
                final password = passwordController.text.trim();
                Provider.of<AuthProvider>(context, listen: false).signIn(email, password);
              },
              child: Text('Sign In'),
            ),
            SizedBox(height: 8),
            TextButton(
              onPressed: () {
                final email = emailController.text.trim();
                final password = passwordController.text.trim();
                Provider.of<AuthProvider>(context, listen: false).signUp(email, password);
              },
              child: Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}

class ColloquiumPage extends StatelessWidget {
  final TextEditingController nameController = TextEditingController();
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Colloquiums'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () {
              Provider.of<AuthProvider>(context, listen: false).signOut();
            },
          ),
        ],
      ),
      body: ColloquiumList(),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) => AddColloquiumDialog(),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}

class AddColloquiumDialog extends StatefulWidget {
  @override
  _AddColloquiumDialogState createState() => _AddColloquiumDialogState();
}

class _AddColloquiumDialogState extends State<AddColloquiumDialog> {
  final TextEditingController nameController = TextEditingController();
  DateTime? selectedDate;
  TimeOfDay? selectedTime;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Add Colloquium'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: nameController,
            decoration: InputDecoration(labelText: 'Name'),
          ),
          SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              DateTime? pickedDate = await showDatePicker(
                context: context,
                initialDate: DateTime.now(),
                firstDate: DateTime.now(),
                lastDate: DateTime(2101),
              );
              if (pickedDate != null) {
                setState(() {
                  selectedDate = pickedDate;
                });
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Pick Date'),
            ),
          ),
          SizedBox(height: 8),
          ElevatedButton(
            onPressed: () async {
              TimeOfDay? pickedTime = await showTimePicker(
                context: context,
                initialTime: TimeOfDay.now(),
              );
              if (pickedTime != null) {
                setState(() {
                  selectedTime = pickedTime;
                });
              }
            },
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Text('Pick Time'),
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: SizedBox(
              child: ElevatedButton(
                onPressed: () {
                  // Assuming eventLocation is a LatLng object representing the event location
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => MapsScreen(eventLocation: LatLng(37.7749, -122.4194)), // Replace with the actual location
                    ),
                  );
                },
                child: Text('Open Map'),
              ),
            ),
          ),
        ],
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
          child: Text('Cancel'),
        ),
        TextButton(
          onPressed: () async {
            final name = nameController.text.trim();
            final date = selectedDate != null ? selectedDate!.toLocal().toIso8601String().split('T')[0] : '';
            final time = selectedTime?.format(context) ?? '';

            if (name.isNotEmpty && date.isNotEmpty && time.isNotEmpty) {
              await addColloquium(context, name, date, time);
              Navigator.of(context).pop();
            } else {
              // Show error message or handle empty fields
            }
          },
          child: Text('Add'),
        ),
      ],
    );
  }

  Future<void> addColloquium(BuildContext context, String name, String date, String time) async {
    final userId = Provider.of<AuthProvider>(context, listen: false).user?.uid;

    if (userId != null) {
      await FirebaseFirestore.instance.collection('colloquiums').doc(userId).collection('user_colloquiums').add({
        'name': name,
        'date': date,
        'time': time,
      }).then((value) async {
        await scheduleNotification(name, date, time);
      });
    }
  }

  Future<void> scheduleNotification(String name, String date, String time) async {
    FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();

    const AndroidNotificationDetails androidPlatformChannelSpecifics = AndroidNotificationDetails(
      'colloquium_channel',
      'Colloquium Notifications',
      importance: Importance.max,
      priority: Priority.high,
    );

    const NotificationDetails platformChannelSpecifics = NotificationDetails(
      android: androidPlatformChannelSpecifics,
    );

    DateTime dateTime = DateTime.parse('$date $time');
    await flutterLocalNotificationsPlugin.zonedSchedule(
      0,
      'Colloquium Reminder',
      '$name at $time on $date',
      tz.TZDateTime.from(dateTime, tz.local),
      platformChannelSpecifics,
      androidAllowWhileIdle: true,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
  }
}

class ColloquiumList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final userId = Provider.of<AuthProvider>(context).user?.uid;

    if (userId != null) {
      return StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance.collection('colloquiums').doc(userId).collection('user_colloquiums').snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return CircularProgressIndicator();
          }

          final colloquiums = snapshot.data?.docs ?? [];

          return GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 8,
              mainAxisSpacing: 8,
            ),
            itemCount: colloquiums.length,
            itemBuilder: (context, index) {
              final colloquium = colloquiums[index];
              final name = colloquium['name'];
              final date = colloquium['date'];
              final time = colloquium['time'];

              return Card(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      name,
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 8),
                    Text('$date\n$time', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey)),
                  ],
                ),
              );
            },
          );
        },
      );
    } else {
      return Center(
        child: Text('User not authenticated'),
      );
    }
  }
}
